﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Tracking_Api.Models;

namespace Tracking_Api.Data
{
    public class IssueDbContext: DbContext
    {
        public IssueDbContext(DbContextOptions<IssueDbContext> options)
           : base(options)
        {

        }
        public DbSet<Issue> Issues { get; set; }
    }
}
